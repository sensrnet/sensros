Polynomial Package (:mod:`numpy.polynomial`)
============================================

.. currentmodule:: numpy.polynomial

Polynomial Classes
------------------
.. autosummary::
   :toctree: generated/

   Polynomial
   Chebyshev
   Legendre
   Hermite
   HermiteE
   Laguerre
