Mathematical functions with automatic domain (:mod:`numpy.emath`)
***********************************************************************

.. currentmodule:: numpy

.. note:: :mod:`numpy.emath` is a preferred alias for :mod:`numpy.lib.scimath`,
          available after :mod:`numpy` is imported.

.. automodule:: numpy.lib.scimath

