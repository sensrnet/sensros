*************************
How to find documentation
*************************

.. seealso:: :ref:`Numpy-specific help functions <routines.help>`

.. automodule:: numpy.doc.howtofind
